# MAYADER!

**Link**:  [Ders](https://github.com/okudan/ders)